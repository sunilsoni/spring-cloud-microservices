package com.jci.flatfile.utils;

import java.util.List;

public class ProcessErrorReq {
	
	private List<String> errorsList;

	public List<String> getErrorsList() {
		return errorsList;
	}

	public void setErrorsList(List<String> errorsList) {
		this.errorsList = errorsList;
	}

	@Override
	public String toString() {
		return "ProcessErrorReq [errorsList=" + errorsList + "]";
	}
	
	
}
