package com.jci.flatfile.service;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jci.flatfile.config.FlatFile;
import com.jci.flatfile.config.SSHConnection;
import com.jci.flatfile.entity.PoEntity;
import com.jci.flatfile.repo.FlatFileRepo;
import com.jci.flatfile.utils.BatchUpdateReq;
import com.jci.flatfile.utils.CommonUtils;
import com.jci.flatfile.utils.Constants;
import com.jci.flatfile.utils.FlatFileRes;
import com.jci.flatfile.utils.PrepareFlatFile;
import com.jci.flatfile.utils.ProcessErrorReq;
import com.jci.flatfile.utils.ProcessErrorRes;
import com.microsoft.azure.storage.StorageException;

@Service
public class FlatFileServiceImpl implements FlatFileService{

    private static final Logger LOG = LoggerFactory.getLogger(FlatFileServiceImpl.class);
    
    @Autowired
    private FlatFileRepo repo;
    
    /** The all erps. */
    @Value("${all.erp.names}")
    private String allErps;
    
    @Autowired
    private FlatFile config;
    
    @Override
    public String processPoFlatFiles() throws InvalidKeyException, URISyntaxException, StorageException {
    	LOG.info("### Starting  FlatFileServiceImpl.processPoFlatFile ####");
        String tempDir = System.getProperty("java.io.tmpdir");
        
        CommonUtils utils = new CommonUtils();
        TreeMap<String,HashMap<Integer,String>> mappingList = utils.getDestMapping(config.getPoMappingFileUrl());
        
        Map<String,List<String>> pkToSuccessList = new HashMap<>();
        Map<String,List<String>> pkToErrorList = new HashMap<>();
        
        PrepareFlatFile file = new PrepareFlatFile();
        ArrayList<String> files = new ArrayList<>();
        String[] erpArr  = allErps.split(",");
        
        List<File> tempFiles = new ArrayList<>();
        for (int i=0;i<erpArr.length;i++){
            String partitionKey = erpArr[i].toUpperCase();
            FlatFileRes res = repo.getPoFlatFileData(partitionKey);
            Map<String, String> rowKeyToPlantMap = res.getRowKeyToPlantMap();
            Map<String, String> rowKeyToSupptypeMap = res.getRowKeyToSupptypeMap();
            
            ArrayList<Map<String,List<HashMap<String, Object>>>> poList = res.getPoList();
            for (Map<String,List<HashMap<String, Object>>> poNumToItemListMap : poList) {
                
                for (Map.Entry<String,List<HashMap<String, Object>>> entry : poNumToItemListMap.entrySet()){
                    
                    String suppType = rowKeyToSupptypeMap.get(entry.getKey());
                    if(mappingList.containsKey(suppType)){
                        Map<String,List<String>> fileNameToRowsMap = file.prepareSuppData(entry.getKey(), mappingList.get(suppType),entry.getValue(),rowKeyToPlantMap.get(entry.getKey()));
                        
                        for (Map.Entry<String,List<String>> entry1 : fileNameToRowsMap.entrySet()){
                            File toFile = new File(tempDir+entry1.getKey());
                             try {
                                    FileUtils.writeLines(toFile,"UTF-8", entry1.getValue(),false);
                                    files.add(toFile.getAbsolutePath());
                                    tempFiles.add(toFile);
                                } catch (IOException e) {
                                    LOG.error("### Exception in   ####",e);
                                }
                        }
                    }
                }
            }
            
        SSHConnection conn =  new SSHConnection(config.getHostname(),config.getPort(),config.getUsername(), config.getPassword());
        List<List<String>> finalList = new ArrayList<>();  
        
        try {
            finalList = conn.sftpUpload(files, Constants.TARGET_DIR);
        } catch (ClassNotFoundException | IOException e) {
        	e.printStackTrace();
        }
        
        LOG.info("finalList===>"+finalList);
        
        if(finalList!=null ){
            if(finalList.get(0).size()>0){
                pkToSuccessList.put(erpArr[i], finalList.get(0));
            }
            if(finalList.get(1).size()>0){
                pkToErrorList.put(erpArr[i], finalList.get(1));
            }
        }
            
      //Update status in PODETAILS Table
        updatePoStatus(pkToSuccessList,pkToErrorList);        
        
        //Need to delete TEMP Files.
        CommonUtils.deleteTempFiles(tempFiles);
        }
        LOG.info("### Ending  FlatFileServiceImpl.processPoFlatFile ####");
        return "Success";
    }

    @Override
    public String processGrFlatFiles() throws InvalidKeyException, URISyntaxException, StorageException {
    	LOG.info("### Starting  FlatFileServiceImpl.processGrFlatFiles ####");
        String tempDir = System.getProperty("java.io.tmpdir");
        
        CommonUtils utils = new CommonUtils();
        TreeMap<String,HashMap<Integer,String>> mappingList = utils.getDestMapping(config.getGrMappingFileUrl());
        
        Map<String,List<String>> pkToSuccessList = new HashMap<>();
        Map<String,List<String>> pkToErrorList = new HashMap<>();
        
        PrepareFlatFile file = new PrepareFlatFile();
        ArrayList<String> files = new ArrayList<>();
        String[] erpArr  = allErps.split(",");
        
        List<File> tempFiles = new ArrayList<>();
        for (int i=0;i<erpArr.length;i++){
            String partitionKey = erpArr[i].toUpperCase();
            
            
            FlatFileRes res = repo.getPoFlatFileData(partitionKey);
            
            
            
            
            
            
            
            Map<String, String> rowKeyToPlantMap = res.getRowKeyToPlantMap();
            Map<String, String> rowKeyToSupptypeMap = res.getRowKeyToSupptypeMap();
            
            ArrayList<Map<String,List<HashMap<String, Object>>>> poList = res.getPoList();
            for (Map<String,List<HashMap<String, Object>>> poNumToItemListMap : poList) {
                
                for (Map.Entry<String,List<HashMap<String, Object>>> entry : poNumToItemListMap.entrySet()){
                    
                    String suppType = rowKeyToSupptypeMap.get(entry.getKey());
                    if(mappingList.containsKey(suppType)){
                        Map<String,List<String>> fileNameToRowsMap = file.prepareSuppData(entry.getKey(), mappingList.get(suppType),entry.getValue(),rowKeyToPlantMap.get(entry.getKey()));
                        
                        for (Map.Entry<String,List<String>> entry1 : fileNameToRowsMap.entrySet()){
                            File toFile = new File(tempDir+entry1.getKey());
                             try {
                                    FileUtils.writeLines(toFile,"UTF-8", entry1.getValue(),false);
                                    files.add(toFile.getAbsolutePath());
                                    tempFiles.add(toFile);
                                } catch (IOException e) {
                                    LOG.error("### Exception in   ####",e);
                                }
                        }
                    }
                }
            }
            
        SSHConnection conn =  new SSHConnection(config.getHostname(),config.getPort(),config.getUsername(), config.getPassword());
        List<List<String>> finalList = new ArrayList<>();  
        
        try {
            finalList = conn.sftpUpload(files, Constants.TARGET_DIR);
        } catch (ClassNotFoundException | IOException e) {
        	e.printStackTrace();
        }
        
        LOG.info("finalList===>"+finalList);
        
        if(finalList!=null ){
            if(finalList.get(0).size()>0){
                pkToSuccessList.put(erpArr[i], finalList.get(0));
            }
            if(finalList.get(1).size()>0){
                pkToErrorList.put(erpArr[i], finalList.get(1));
            }
        }
            
      //Update status in PODETAILS Table
        updatePoStatus(pkToSuccessList,pkToErrorList);        
        
        //Need to delete TEMP Files.
        CommonUtils.deleteTempFiles(tempFiles);
        }
        LOG.info("### Ending  FlatFileServiceImpl.processGrFlatFiles ####");
        return "Success";
    }

    @Override
    public String processSuppFlatFiles() throws InvalidKeyException, URISyntaxException, StorageException {
    	LOG.info("### Starting  FlatFileServiceImpl.processSuppFlatFiles ####");
        String tempDir = System.getProperty("java.io.tmpdir");
        
        CommonUtils utils = new CommonUtils();
        TreeMap<String,HashMap<Integer,String>> mappingList = utils.getDestMapping(config.getSuppMappingFileUrl());
        
        Map<String,List<String>> pkToSuccessList = new HashMap<>();
        Map<String,List<String>> pkToErrorList = new HashMap<>();
        
        PrepareFlatFile file = new PrepareFlatFile();
        ArrayList<String> files = new ArrayList<>();
        String[] erpArr  = allErps.split(",");
        
        List<File> tempFiles = new ArrayList<>();
        for (int i=0;i<erpArr.length;i++){
            String partitionKey = erpArr[i].toUpperCase();
            
            FlatFileRes res = repo.getFlatFileData(partitionKey,Constants.TABLE_SUPPLIER);
            
            
            //plant name to total records map
            
            Map<String, String> rowKeyToPlantMap = res.getRowKeyToPlantMap();
            Map<String, String> rowKeyToSupptypeMap = res.getRowKeyToSupptypeMap();
            List<HashMap<String, Object>> rowList = res.getList();
            
            Map<String, List<HashMap<String, Object>>> plantToRowsMap = new HashMap<>();
            
            for (Map.Entry<String, String> entry : rowKeyToPlantMap.entrySet()) {
            	
            	 
            }
            
  
            
            for (HashMap<String, Object> rowkeyToVal : rowList) {
            	
            	if(rowKeyToPlantMap.containsKey())
            	plantToRowsMap.put(key, value)
            }
            
            for (Map<String,List<HashMap<String, Object>>> poNumToItemListMap : rowList) {
                
                for (Map.Entry<String,List<HashMap<String, Object>>> entry : poNumToItemListMap.entrySet()){
                    
                    String suppType = rowKeyToSupptypeMap.get(entry.getKey());
                    if(mappingList.containsKey(suppType)){
                        Map<String,List<String>> fileNameToRowsMap = file.prepareSuppData(entry.getKey(), mappingList.get(suppType),entry.getValue(),rowKeyToPlantMap.get(entry.getKey()));
                        
                        for (Map.Entry<String,List<String>> entry1 : fileNameToRowsMap.entrySet()){
                            File toFile = new File(tempDir+entry1.getKey());
                             try {
                                    FileUtils.writeLines(toFile,"UTF-8", entry1.getValue(),false);
                                    files.add(toFile.getAbsolutePath());
                                    tempFiles.add(toFile);
                                } catch (IOException e) {
                                    LOG.error("### Exception in   ####",e);
                                }
                        }
                    }
                }
            }
            
        SSHConnection conn =  new SSHConnection(config.getHostname(),config.getPort(),config.getUsername(), config.getPassword());
        List<List<String>> finalList = new ArrayList<>();  
        
        try {
            finalList = conn.sftpUpload(files, Constants.TARGET_DIR);
        } catch (ClassNotFoundException | IOException e) {
        	e.printStackTrace();
        }
        
        LOG.info("finalList===>"+finalList);
        
        if(finalList!=null ){
            if(finalList.get(0).size()>0){
                pkToSuccessList.put(erpArr[i], finalList.get(0));
            }
            if(finalList.get(1).size()>0){
                pkToErrorList.put(erpArr[i], finalList.get(1));
            }
        }
            
      //Update status in PODETAILS Table
        updatePoStatus(pkToSuccessList,pkToErrorList);        
        
        //Need to delete TEMP Files.
        CommonUtils.deleteTempFiles(tempFiles);
        }
        LOG.info("### Ending  FlatFileServiceImpl.processSuppFlatFiles ####");
        return "Success";
    
    }

    @Override
    public String processItemFlatFiles() throws InvalidKeyException, URISyntaxException, StorageException {
    	
    	 return null;
    }
    
    
//PO Table status update
    private synchronized void updatePoStatus(Map<String,List<String>> pkToSuccessList,Map<String,List<String>> pkToErrorList) {
    	LOG.info("### Starting in FlatFileServiceImpl.updateStatus ###");
        BatchUpdateReq updateReq =null;
        for (Map.Entry<String,List<String>> entry : pkToSuccessList.entrySet()){
            updateReq = new  BatchUpdateReq ();
            updateReq.setSuccess(true);
            updateReq.setErpName(entry.getKey().toUpperCase());
             
            try {
                List<PoEntity> poEntity = repo.getPoDetails(entry.getKey().toUpperCase(),entry.getValue());
                LOG.info("poEntity size--->"+poEntity.size());
                
                HashMap<String,List<PoEntity>> tableNameToEntityMap = new HashMap<>();
                tableNameToEntityMap.put(Constants.TABLE_PO_DETAILS, poEntity);
                updateReq.setTableNameToEntityMap(tableNameToEntityMap);        
                repo.batchUpdate(updateReq);    
            } catch (InvalidKeyException | URISyntaxException | StorageException e) {
                LOG.error("### Exception in  FlatFileServiceImpl.updateStatus ####",e);                
            }
        }
        
        for (Map.Entry<String,List<String>> entry : pkToErrorList.entrySet()){
            updateReq = new  BatchUpdateReq ();
            updateReq.setSuccess(false);
            updateReq.setErpName(entry.getKey().toUpperCase());
            String partitionKey = entry.getKey().toUpperCase();
            try {
                List<PoEntity>  poEntity = repo.getPoDetails(partitionKey,entry.getValue());
                HashMap<String,List<PoEntity>> tableNameToEntityMap = new HashMap<>();
                tableNameToEntityMap.put(Constants.TABLE_PO_DETAILS, poEntity);
                updateReq.setTableNameToEntityMap(tableNameToEntityMap);
                repo.batchUpdate(updateReq);
            } catch (InvalidKeyException | URISyntaxException | StorageException e) {
                LOG.error("### Exception in  FlatFileServiceImpl.updateStatus ####",e);
                
            }
        }
        LOG.info("### Ending in FlatFileServiceImpl.updateStatus ###");
    }
	private boolean updateStatus(Map<String,List<String>> pkToSuccessList,String globalId,String userName,String comment) {
		boolean isUpdated=false;
		BatchUpdateReq updateReq =null;
		for (Map.Entry<String,List<String>> entry : pkToSuccessList.entrySet()){
			updateReq = new  BatchUpdateReq ();
			updateReq.setSuccess(true);
			updateReq.setErpName(entry.getKey().toUpperCase());
			 
			String partitionKey = entry.getKey().toUpperCase();
			try {
				List<PoEntity> poEntity = repo.getPoDetails(partitionKey,entry.getValue());
				HashMap<String,List<PoEntity>> tableNameToEntityMap = new HashMap<>();
				tableNameToEntityMap.put(Constants.TABLE_PO_DETAILS, poEntity);
				updateReq.setTableNameToEntityMap(tableNameToEntityMap);
				
				updateReq.setComment(comment);
				updateReq.setUserName(userName);
				updateReq.setGlobalId(globalId);
				repo.batchUpdate(updateReq);
				isUpdated=true;
			} catch (InvalidKeyException | URISyntaxException | StorageException e) {
				LOG.error("### Exception in FlatFileServiceImpl.updateStatus  ####",e);				
			}
		}
		return isUpdated;
	} 
	@Override
	public ProcessErrorRes processErrorPosFlatFiles(ProcessErrorReq req){
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProcessErrorRes processErrorGrFlatFiles(ProcessErrorReq req){
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProcessErrorRes processErrorItemFlatFiles(ProcessErrorReq req){
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProcessErrorRes processErrorSuppFlatFiles(ProcessErrorReq req){
		// TODO Auto-generated method stub
		return null;
	}
    
}
