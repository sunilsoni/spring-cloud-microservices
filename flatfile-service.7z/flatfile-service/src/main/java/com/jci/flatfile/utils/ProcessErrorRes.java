package com.jci.flatfile.utils;

import java.util.Map;

public class ProcessErrorRes {

	private Map<String, String> typeToStatusMap;

	public Map<String, String> getTypeToStatusMap() {
		return typeToStatusMap;
	}

	public void setTypeToStatusMap(Map<String, String> typeToStatusMap) {
		this.typeToStatusMap = typeToStatusMap;
	}

	@Override
	public String toString() {
		return "ProcessErrorRes [typeToStatusMap=" + typeToStatusMap + "]";
	}
	
}
