/**
 * (C) Copyright 2016 Johnson Controls, Inc
 * Use or Copying of all or any part of this program, except as
 * permitted by License Agreement, is prohibited.
 */
package com.jci.flatfile.utils;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * The Class CommonUtils.
 */
public class CommonUtils {
	
	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(CommonUtils.class);
	
	/**
	 * String to date.
	 *
	 * @param dateStr the date str
	 * @return the date
	 */
	static Date stringToDate(String dateStr){
		if(StringUtils.isBlank(dateStr) || "null".equals(dateStr)){
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	    Date convertedCurrentDate=null;
		try {
			convertedCurrentDate = sdf.parse(dateStr);
		} catch (ParseException e) {
			LOG.error("### Exception in   ####",e);
			
		}
	   return convertedCurrentDate;
	}
	
	
	/**
	 * Gets the dest mapping.
	 *
	 * @param folderUrl the folder url
	 * @return the dest mapping
	 */
	public TreeMap<String,HashMap<Integer,String>> getDestMapping(String folderUrl){
		HashMap<Integer, String> map=null;
		ObjectMapper mapper = new ObjectMapper(); 
		
		TreeMap<String,HashMap<Integer,String>> mappingList = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
		File folder = new File(folderUrl);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {//reading only 1 file need to make changes
	      if (listOfFiles[i].isFile()) {
		    TypeReference<HashMap<Integer,String>> typeRef  = new TypeReference<HashMap<Integer,String>>() {};
			try {
				map = mapper.readValue(listOfFiles[i], typeRef);
				mappingList.put(FilenameUtils.removeExtension(listOfFiles[i].getName()), map);
			} catch (IOException e) {
				LOG.error("### Exception in   ####",e);
				
			} 
	      } 
		}
		return mappingList ;
	}
	
	public static String removeTemp(String str){
		int index=0;
	    if(str.contains("\\")){
	    	index = str.lastIndexOf("\\");
	    }else{
	    	index = str.lastIndexOf("/");
	    }
	    
	    str =  str.substring(index+1);
	    
		return str;
	}
	
	public static File createTempDirectory() throws IOException{
		    final String baseTempPath = System.getProperty("java.io.tmpdir");

		    File tempDir = new File(baseTempPath + File.separator + "SCTemp" + System.nanoTime());
		    if (tempDir.exists() == false) {
		        tempDir.mkdir();
		    }

		    return tempDir;
	}
	
	public static void deleteTempFiles(List<File> tempFiles){
		  for (File temp : tempFiles) {
	            try {
					FileDeleteStrategy.FORCE.delete(temp);
				} catch (IOException e) {
					e.printStackTrace();
				}
	        }  
	}
	
}
